#set up
from google.colab import drive
drive.mount('/content/drive')

import spacy
import os
from sklearn.linear_model import LogisticRegression

import numpy as np

# Load the English language model
nlp = spacy.load("en_core_web_sm")

import spacy
import os



# Function to extract unique adjectives from a text
#this is an helper to help with a single document
def extract_unique_adjectives(text):
    # Initialize a set to store unique adjectives
    unique_adjectives = set()
    # Process the text with spaCy
    doc = nlp(text)
    # Iterate over each token in the document
    for token in doc:
        # Check if the token is an adjective and add it to the set if it is
        if token.pos_ == "ADJ":
            unique_adjectives.add(token.text)
    return unique_adjectives

# Function to process each file in a folder
#this is an helper function to loop all the example
def get_all_the_unique_adjectives(folder_path1, folder_path2):
    #total unique sets of adjectives 
    all_adjective = set()
    # Iterate through each file in the first folder
    for filename in os.listdir(folder_path1):
        # Check if the file is a text file
        if filename.endswith(".txt"):
            # Read the contents of the file
            with open(os.path.join(folder_path1, filename), "r", encoding="utf-8") as file:
                text = file.read()
            # Extract unique adjectives from the text
            unique_adjectives = extract_unique_adjectives(text)
            all_adjective.update(unique_adjectives)
           
    
    # Iterate through each file in the second folder
    for filename in os.listdir(folder_path2):
        # Check if the file is a text file
        if filename.endswith(".txt"):
            # Read the contents of the file
            with open(os.path.join(folder_path2, filename), "r", encoding="utf-8") as file:
                text = file.read()
            # Extract unique adjectives from the text
            unique_adjectives = extract_unique_adjectives(text)
            all_adjective.update(unique_adjectives)
            
    
    print(len(all_adjective))
    # print(all_adjective)
    return all_adjective

#get the set of adjectives
#map them to a number
def convert_set_dictionary(adj_set):
    # Initialize an empty dictionary
    result_dict = {}
    # Iterate over the set and assign each element an index as the value
    for index, element in enumerate(adj_set):
        result_dict[element] = index
    return result_dict

def create_a_vector_of_adjective_vocabulary_length(length_of_vector):
  return np.zeros(length_of_vector)

#cretae the output label
def creata_output_label_for_train_data_and_test_data():
  train_label = np.concatenate((np.ones(800), np.zeros(800)))
  test_label = np.concatenate((np.ones(200), np.zeros(200)))

  return train_label, test_label   



#process all the data into matrix
#there are 1600 examples
#the output matrix will have (1600, the size of the unique adjectives)
def process_data_into_matrix(folder_path1, folder_path2, adjectives_map, len_of_adjectives):
    X = np.empty((0, len_of_adjectives))

    # Iterate through each file in the first folder
    for filename in os.listdir(folder_path1):
        if filename.endswith(".txt"):
            with open(os.path.join(folder_path1, filename), "r", encoding="utf-8") as file:
                text = file.read()
            unique_adjectives = extract_unique_adjectives(text)

            x_i = np.zeros((1, len_of_adjectives))
            for adj in unique_adjectives:
                if adj in adjectives_map:
                    pos_in_xi_vec = adjectives_map[adj]
                    x_i[0, pos_in_xi_vec] = 1
            X = np.vstack([X, x_i])

    # Iterate through each file in the second folder
    for filename in os.listdir(folder_path2):
        if filename.endswith(".txt"):
            with open(os.path.join(folder_path2, filename), "r", encoding="utf-8") as file:
                text = file.read()
            unique_adjectives = extract_unique_adjectives(text)

            x_i = np.zeros((1, len_of_adjectives))
            for adj in unique_adjectives:
                if adj in adjectives_map:
                    pos_in_xi_vec = adjectives_map[adj]
                    x_i[0, pos_in_xi_vec] = 1
            X = np.vstack([X, x_i])

    print(X.shape)
    return X




from sklearn.metrics import f1_score
#train the model
#logistic regression
#test on the training data
#test on the test data
def train_and_predict(X_train, y_train, X_test, y_test):
    # Create a logistic regression model
    log_reg = LogisticRegression()
    
    # Train the model using the training data and labels
    log_reg.fit(X_train, y_train)
    
    # Make predictions on training data
    y_train_pred = log_reg.predict(X_train)
    
    # Make predictions on test data
    y_test_pred = log_reg.predict(X_test)
    
    # Calculate F1 score for training data
    f1_train = f1_score(y_train, y_train_pred, average='macro')
    
    # Calculate F1 score for test data
    f1_test = f1_score(y_test, y_test_pred, average='macro')
    
    return f1_train, f1_test







                  


# Directories containing the text files
folder_path1_train_pos = "/content/drive/MyDrive/nlp/hw3/review_polarity/txt_sentoken/pos_train"
folder_path2_train_neg = "/content/drive/MyDrive/nlp/hw3/review_polarity/txt_sentoken/neg_train"


# get all the unique adjectives
adj_set = get_all_the_unique_adjectives(folder_path1_train_pos, folder_path2_train_neg)
adj_mapping = convert_set_dictionary(adj_set)

X_train = process_data_into_matrix(folder_path1_train_pos, folder_path2_train_neg, adj_mapping, len(adj_set))
y_train, y_test = creata_output_label_for_train_data_and_test_data() 

#test data
folder_path1_test_pos = "/content/drive/MyDrive/nlp/hw3/review_polarity/txt_sentoken/pos_test"
folder_path2_test_neg = "/content/drive/MyDrive/nlp/hw3/review_polarity/txt_sentoken/neg_test"

#process test data into matrix form
X_test = process_data_into_matrix(folder_path1_test_pos, folder_path2_test_neg, adj_mapping, len(adj_set))

#get the necessary measurements
f1_train_score, f1_test_score = train_and_predict(X_train, y_train, X_test, y_test)
print("F1 score on training data:", f1_train_score)
print("F1 score on test data:", f1_test_score)