import numpy as np

#initial probability
initial_probs = {
    "N": 0.7,
    "M": 0.1,
    "V": 0.2
    
}
#transition probability
transition_probs = {
    "N-N" : 0.2,
    "N-M" : 0.3,
    "N-V" : 0.5,
    "M-N" : 0.4,
    "M-M" : 0.1,
    "M-V" : 0.5,
    "V-N" : 0.8,
    "V-M" : 0.1,
    "V-V" : 0.1

}

#emission probability
emission_probs = {
   "N-PATRICK" : 0.3,
   "N-CHERRY" : 0.2,
   "N-CAN" : 0.1, 
   "N-WILL" : 0.1,
   "N-SEE" : 0.1,
   "N-SPOT": 0.2,

  "M-PATRICK" : 0,
   "M-CHERRY" : 0,
   "M-CAN" : 0.4, 
   "M-WILL" : 0.6,
   "M-SEE" : 0,
   "M-SPOT": 0,

  "V-PATRICK" : 0,
   "V-CHERRY" : 0,
   "V-CAN" : 0.1, 
   "V-WILL" : 0.2,
   "V-SEE" : 0.5,
   "V-SPOT": 0.2,
   
}


#forward algorithm
def forward_algorithm(table, sequence, init_probs, trans_probs, emi_probs):
    # Initialize the first column of the table with initial probabilities
    for state in range(len(init_probs)):
        table[state, 0] = emi_probs[list(init_probs.keys())[state] + "-" + sequence[0]] * list(init_probs.values())[state]

    # Populate the rest of the table
    for t in range(1, len(sequence)):
        for state in range(len(init_probs)):
            total_prob = 0
            for prev_state in range(len(init_probs)):
                # Accumulate the probabilities and update the table
                total_prob += emi_probs[list(init_probs.keys())[state] + "-" + sequence[t]] * \
                              trans_probs[list(init_probs.keys())[prev_state] + "-" + list(init_probs.keys())[state]] * \
                              table[prev_state, t - 1]
            table[state, t] = total_prob






#viterbi algorithm
def viterbi(table, sequence, init_probs, trans_probs, emi_probs):

  # Initialize the first column of the table with initial probabilities
    for state in range(len(init_probs)):
        table[state, 0] = emi_probs[list(init_probs.keys())[state] + "-" + sequence[0]] * list(init_probs.values())[state]

    # Populate the rest of the table
    for t in range(1, len(sequence)):
        for state in range(len(init_probs)):
            max_prob = 0
            for prev_state in range(len(init_probs)):
                # Calculate the maximum probability and update the table
                prob = emi_probs[list(init_probs.keys())[state] + "-" + sequence[t]] * \
                       trans_probs[list(init_probs.keys())[prev_state] + "-" + list(init_probs.keys())[state]] * \
                       table[prev_state, t - 1]
                if prob > max_prob:
                    max_prob = prob
            table[state, t] = max_prob
   
    # print(sequence[i])


#after calculation
#the table is given to these function
#it decodes it
def decodeSequence(dp_table):

    #used to map the sequence to english
    vit_map ={
        0: "N",
        1: "M",
        2: "V"
    }

    num_states, sequence_length = dp_table.shape
    # Initialize an empty list to store the decoded sequence
    decoded_sequence = []

    # Start from the last time step and backtrack to find the most likely sequence
    max_state_index = np.argmax(dp_table[:, -1])
    decoded_sequence.append(max_state_index)

    # Backtrack through the table
    for t in range(sequence_length - 1, 0, -1):
        prev_max_state_index = np.argmax(dp_table[:, t - 1])
        decoded_sequence.insert(0, prev_max_state_index)

    print("The mostly likely tag sequences are ........")
    for i in decoded_sequence:
      print(vit_map[i])

    print("\nProbabilities of the states in the most likely sequences:")
    for t, state_index in enumerate(decoded_sequence):
        print(vit_map[state_index], "with probability of:", dp_table[state_index, t])
    print("\n")
    # print("Probabilities of the states in the most likely sequences")
    # index_of_dp_table = 0
    # for i in decoded_sequence:
    #   if vit_map[i] == "N":
    #     print("N with probability of: ", dp_table[0, index_of_dp_table])
    #   if vit_map[i] == "M":
    #     print("M with probability of: ", dp_table[1, index_of_dp_table])
    #   if vit_map[i] == "V":
    #     print("V with probability of: ", dp_table[2, index_of_dp_table])
    #   index_of_dp_table = index_of_dp_table + 1


#store the sequence
viterbi_sequence_1 = ["patrick", "can", "see", "cherry"]
# viterbi_sequence = ["patrick", "can", "see", "cherry"]
print("for the sequence: ",viterbi_sequence_1)
#process the sequence. uppercase it
uppercased_seq_1 = [token.upper() for token in viterbi_sequence_1]
#initialize an numpy of zeros for calculation
viterbi_dynamic_table_1 = np.zeros((len(initial_probs), len(uppercased_seq_1)))
#do the calculation
viterbi(viterbi_dynamic_table_1, uppercased_seq_1, initial_probs, transition_probs, emission_probs)
print("probability for each state")
print(viterbi_dynamic_table_1)
#decode the sequence
decodeSequence(viterbi_dynamic_table_1)


#store the sequence
viterbi_sequence = ["will", "cherry", "spot", "patrick"]
# viterbi_sequence = ["patrick", "can", "see", "cherry"]
print("for the sequence: ",viterbi_sequence)
#process the sequence. uppercase it
uppercased_seq = [token.upper() for token in viterbi_sequence]
#initialize an numpy of zeros for calculation
viterbi_dynamic_table = np.zeros((len(initial_probs), len(uppercased_seq)))
#do the calculation
viterbi(viterbi_dynamic_table, uppercased_seq, initial_probs, transition_probs, emission_probs)
print("probability for each state")
print(viterbi_dynamic_table)
#decode the sequence
decodeSequence(viterbi_dynamic_table)


#forward sequence calculation
# forward_sequence = ["will", "cherry", "spot", "patrick"]
# forward_sequence = [token.upper() for token in forward_sequence]
# forward_dynamic_table = np.zeros((len(initial_probs), len(forward_sequence)))
# forward_algorithm(forward_dynamic_table, forward_sequence, initial_probs, transition_probs, emission_probs)

# print(forward_dynamic_table)

